var searchData=
[
  ['size_517',['size',['../structGLFWgammaramp.html#ad620e1cffbff9a32c51bca46301b59a5',1,'GLFWgammaramp']]],
  ['standard_20cursor_20shapes_518',['Standard cursor shapes',['../group__shapes.html',1,'']]],
  ['standards_20conformance_519',['Standards conformance',['../compat_guide.html',1,'']]]
];
